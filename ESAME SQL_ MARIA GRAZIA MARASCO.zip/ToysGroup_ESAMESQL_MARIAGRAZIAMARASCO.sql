DROP SCHEMA IF EXISTS ToysGroup; 
CREATE SCHEMA ToysGroup;
USE ToysGroup;
-- creazione tabella productCategory;
CREATE TABLE productCategory(
productCategoryID INT PRIMARY KEY AUTO_INCREMENT
, productCategoryName VARCHAR(50)
);
-- creazione tabella product;
CREATE TABLE product (
productID INT PRIMARY KEY 
, productName VARCHAR(50)
, productCategoryID INT
, productPrice DECIMAL(10,2)
, CONSTRAINT FK_productCategory_product FOREIGN KEY (productCategoryID) REFERENCES productCategory(productCategoryID)
);
-- creazione tabella Region
CREATE TABLE salesRegion(
salesRegionID INT PRIMARY KEY AUTO_INCREMENT
, salesRegionName VARCHAR(50)
);
-- creazione tabella state
CREATE TABLE state(
stateID INT PRIMARY KEY AUTO_INCREMENT
, stateName VARCHAR(50)
, salesRegionID INT
, CONSTRAINT FK_salesRegion_state FOREIGN KEY (salesRegionID) REFERENCES salesRegion(salesRegionID)
);
-- creazione tabella sales
CREATE TABLE sales (
    salesID INT PRIMARY KEY AUTO_INCREMENT
    , productID INT
    , stateID INT 
    , saleDate DATE 
    , quantity INT 
    , totalAmount DECIMAL(10, 2) 
    , CONSTRAINT FK_product_sales FOREIGN KEY (productID) REFERENCES product(productID)
    , CONSTRAINT FK_state_sales FOREIGN KEY (stateID) REFERENCES state(stateID)
   );
-- popolamento varie tabelle
INSERT INTO productCategory (productCategoryName) VALUES 
('Puzzles')
, ('Action Figures')
, ('Educational Toys')
, ('Dolls')
, ('Board Games') 
, ('Outdoor Toys')
, ('Electronic Toys')
, ('Plush Toys')
, ('Creative Kits')
, ('Vehicles');

-- Popolamento della tabella product
INSERT INTO product (productID, productName, productCategoryID, productPrice) VALUES
(101, '3D Puzzle Castle', 1, 29.99)
, (102, 'Superhero Action Figure', 2, 19.99)
, (103, 'Alphabet Blocks', 3, 14.99)
, (104, 'Fashion Doll', 4, 24.99)
, (105, 'Classic Chess Set', 5, 39.99)
, (106, 'Advanced Robot Kit', 7, 89.99) -- Prodotto invenduto
, (107, 'Magnetic Building Tiles', 3, 49.99)
, (108, 'Plush Teddy Bear', 8, 15.99)
, (109, 'Remote Control Car', 10, 59.99)
, (110, 'DIY Bracelet Kit', 9, 9.99)
, (111, 'Outdoor Swing Set', 6, 199.99)
, (112, 'LED Drawing Board', 7, 34.99)
, (113, 'Train Set Deluxe', 10, 74.99)
, (114, 'Miniature Farm Animals', 3, 12.99)
, (115, 'Pirate Adventure Board Game', 5, 44.99)
, (116, 'Talking Parrot Plush', 8, 22.99)
, (117, 'Space Exploration Kit', 3, 69.99)
, (118, 'Water Balloon Launcher', 6, 19.99)
, (119, 'Wooden Rocking Horse', 6, 89.99) -- Prodotto invenduto
, (120, 'Glow-in-the-Dark Puzzle', 1, 24.99);

-- Popolamento della tabella salesRegion
INSERT INTO salesRegion (salesRegionName) VALUES
('WestEurope')
, ('SouthEurope')
, ('NorthAmerica')
, ('AsiaPacific')
, ('SouthAmerica')
, ('MiddleEast')
, ('Africa');
-- Popolamento della tabella state
INSERT INTO state (stateName, salesRegionID) VALUES
('Germany', 1)
, ('France', 1)
, ('Italy', 1)
, ('Spain', 1)
, ('USA', 2) 
, ('Canada', 2)
, ('Japan', 3)
, ('China', 3)
, ('India', 3)
, ('Brazil', 4)
, ('Argentina', 4)
, ('Australia', 5)
, ('UAE', 6)
, ('Saudi Arabia', 6)
, ('South Africa', 7)
, ('Kenya', 7)
, ('Netherlands', 1)
, ('Mexico', 4)
, ('Russia', 3)
, ('South Korea', 3);

-- Popolamento della tabella sales
INSERT INTO sales (productID, stateID, saleDate, quantity, totalAmount) VALUES
(101, 1, '2022-01-10', 15, 449.85)
, (102, 2, '2022-02-20', 10, 199.90)
, (103, 3, '2022-03-05', 25, 374.75)
, (104, 4, '2022-04-10', 12, 299.88)
, (105, 5, '2022-05-22', 6, 239.94)
, (107, 6, '2022-06-30', 18, 899.82)
, (109, 7, '2022-07-15', 22, 1319.78)
, (108, 8, '2022-08-10', 30, 479.70)
, (113, 9, '2022-09-05', 8, 599.92)
, (115, 10, '2022-10-11', 20, 899.80)
, (118, 11, '2022-11-14', 50, 999.50)
, (110, 12, '2022-12-01', 40, 399.60)
, (103, 13, '2023-01-05', 25, 374.75)
, (104, 14, '2023-02-09', 10, 249.90)
, (102, 15, '2023-03-22', 15, 299.85)
, (116, 16, '2023-04-18', 9, 206.91)
, (117, 17, '2023-05-10', 7, 489.93)
, (120, 18, '2023-06-01', 14, 349.86)
, (112, 19, '2023-07-20', 5, 174.95)
;
INSERT INTO sales (productID, stateID, saleDate, quantity, totalAmount) VALUES
-- Vendite del 2022
(101, 1, '2022-01-15', 15, 449.85)
, (102, 2, '2022-03-10', 12, 239.88)
, (103, 3, '2022-04-05', 20, 299.80)
, (104, 4, '2022-05-15', 10, 249.90)
, (105, 5, '2022-06-20', 8, 319.92)
, (107, 6, '2022-07-25', 25, 1249.75)
, (109, 7, '2022-08-30', 18, 1079.82)
, (108, 9, '2022-09-15', 30, 479.70)
, (113, 11, '2022-10-10', 10, 749.90)
, (115, 12, '2022-11-20', 22, 989.78)
, (118, 13, '2022-12-05', 40, 799.60)
-- Vendite del 2023
, (101, 14, '2023-01-12', 5, 149.95) 
, (116, 15, '2023-02-14', 12, 275.88)
, (117, 16, '2023-03-22', 6, 419.94)
, (103, 17, '2023-04-15', 10, 149.90)
, (104, 18, '2023-05-10', 8, 199.92)
, (102, 19, '2023-06-18', 15, 299.85)
, (120, 20, '2023-07-20', 7, 174.93)
, (112, 9, '2023-08-15', 10, 349.90)
, (115, 13, '2023-10-11', 18, 809.82)
, (107, 5, '2023-11-15', 9, 449.91)
, (109, 8, '2023-12-20', 22, 1319.78)
-- Vendite del 2024
, (101, 1, '2024-01-20', 20, 599.80)
, (102, 2, '2024-02-15', 10, 199.90)
, (103, 3, '2024-03-10', 18, 269.82)
, (104, 4, '2024-04-12', 15, 374.85)
, (105, 6, '2024-05-05', 25, 999.75)
, (107, 5, '2024-06-18', 20, 999.80)
, (112, 7, '2024-07-22', 12, 419.88)
, (118, 9, '2024-08-15', 35, 699.65)
, (109, 20, '2024-09-20', 8, 479.92)
, (115, 10, '2024-10-12', 10, 449.90)
, (116, 14, '2024-11-05', 5, 114.95)
, (120, 15, '2024-12-19', 8, 199.92);  
/* TASK 4.1 
verificare che i campi definiti come PK siano univoci (vari metodi proposti)*/
-- tabella productCategory
SELECT
  productCategoryID
  FROM
  productCategory
  GROUP BY 
  productCategoryID
  HAVING
  count(*)>1;
-- tabella product
SELECT 
	Column_name 
  FROM
	information_schema.Key_column_usage
  WHERE 
	TABLE_NAME = 'product'
  AND
    CONSTRAINT_NAME = 'Primary'
  AND
    TABLE_SCHEMA = 'toysgroup';
-- tabella salesRegion
SHOW INDEX FROM salesRegion;
-- tabella state
DESCRIBE state; 
-- tabella sales
SELECT
  salesID
  FROM
  sales
  GROUP BY 
  salesID
  HAVING
  count(*)>1;
/* TASK 4.2
esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, 
il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita 
e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno 
(>180 -> True, <= 180 -> False)*/
SELECT 
    S.salesID AS CodiceDocumento
    , S.saleDate AS DataTransazione
    , P.productName AS NomeProdotto
    , PC.productCategoryName AS CategoriaProdotto
    , ST.stateName AS Stato
    , SR.salesRegionName AS Regione
    , IF(DATEDIFF(CURDATE(), S.saleDate) > 180, "True", "False") AS PiùDi180Giorni
FROM sales S
INNER JOIN product P ON S.productID = P.productID
INNER JOIN productCategory PC ON P.productCategoryID = PC.productCategoryID
INNER JOIN state ST ON S.stateID = ST.stateID
INNER JOIN salesRegion SR ON ST.salesRegionID = SR.salesRegionID
ORDER BY dataTransazione DESC;
/* TASK4.3
esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano).
Nel result set devono comparire solo il codice prodotto e il totale venduto.
*/
SELECT 
    ProductID
    , SUM(Quantity) AS TotaleVenduto
FROM Sales 
GROUP BY ProductID
HAVING TotaleVenduto > (
    SELECT 
		AVG(quantitàTotale) 
    FROM (
        SELECT SUM(S.Quantity) AS quantitàTotale
        FROM Sales S
        WHERE YEAR(S.saleDate) = (SELECT MAX(YEAR(saleDate)) FROM Sales) 
        GROUP BY S.ProductID
    ) AS mediaVenditeUltimoAnno
);
/*
TASK4.4
esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
 */
SELECT 
    P.ProductID AS IDprodotto
    , P.ProductName AS NomeProdotto
    , YEAR(S.saleDate) AS AnnoVendita
    , SUM(S.TotalAmount) AS FatturatoTotale
FROM Sales AS S
LEFT JOIN Product P ON S.ProductID = P.ProductID -- facendo un RIGHT join includerei anche l'invenduto
GROUP BY P.ProductID, YEAR(S.saledate)
;
/* TASK4.5. 
esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
*/
SELECT 
    ST.stateName AS Stato
    , YEAR(S.saleDate) AS AnnoVendita
    , SUM(S.totalAmount) AS FatturatoTotale
FROM sales S
RIGHT JOIN state ST ON S.stateID = ST.stateID
RIGHT JOIN salesRegion SR ON ST.salesRegionID = SR.salesRegionID
GROUP BY ST.stateName, YEAR(S.saleDate)
ORDER BY annoVendita, fatturatoTotale DESC;

/*TASK4.6
rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
*/
SELECT 
    C.productCategoryName AS CategoriaProdotto
    , SUM(S.Quantity) AS QuantitàVenduta
FROM Sales S
LEFT JOIN Product P ON S.ProductID = P.ProductID
LEFT JOIN productCategory C ON P.productCategoryID = C.productCategoryID
GROUP BY C.productCategoryName
ORDER BY quantitàVenduta DESC
LIMIT 1; -- per visualizzare solo il primo, quindi il più richiesto. 

/*TASK4.7
rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
*/
-- approccio 1: join
SELECT 
    P.ProductID AS IDprodotto
    , P.ProductName AS NomeProdotto
FROM Product AS P
LEFT JOIN Sales S ON S.ProductID = P.ProductID
WHERE S.ProductID IS NULL;
-- approccio 2: subquery
SELECT 
    P.ProductID AS IDprodotto
    , P.ProductName AS NomeProdotto
FROM Product AS P
WHERE P.ProductID NOT IN (
    SELECT DISTINCT S.ProductID
    FROM Sales S
);
/*TASK 4.8
creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle
 informazioni utili (codice prodotto, nome prodotto, nome categoria)*/
CREATE VIEW InfoUtili AS
SELECT 
    P.ProductID
    , P.ProductName
    , C.productCategoryName
FROM Product P
LEFT JOIN productCategory C ON P.productCategoryID = C.productCategoryID;

/*TASK 4.9
creare una vista per le informazioni geografiche
*/
CREATE VIEW InfoGeografiche AS
SELECT 
    SR.salesRegionID
    , SR.salesRegionName
    , ST.stateID
    , ST.stateName
FROM salesRegion AS SR
INNER JOIN state ST ON SR.salesRegionID = ST.salesRegionID;

